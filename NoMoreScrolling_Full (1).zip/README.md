# NoMoreScrolling

This repository contains both a web demo (Website/) and an Android Studio project (AndroidApp/).
- Website is a lightweight HTML demo suitable for GitHub Pages (open Website/index.html).
- AndroidApp is an import-ready Android Studio project (Java). Open AndroidApp in Android Studio and run on a device.

